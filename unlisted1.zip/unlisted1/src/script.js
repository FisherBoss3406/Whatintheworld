const games = [
  { name: "Shadow Browser", url: "https://shadowbrowser.com/" },
  { name: "Google", url: "https://www.google.com/" },
  { name: "Crazy Games", url: "https://www.crazygames.com/" },
  { name: "Agar.io", url: "https://agargame.io/" },
  { name: "Slither.io", url: "https://slitheronline.io/" },
  { name: "Little Alchemy", url: "https://littlealchemy.com/" },
  { name: "Cool Math Games", url: "https://www.coolmathgames.com/" },
  { name: "Krunker.io", url: "https://krunker.io/" },
  { name: "Google Chrome Dino Game", url: "https://chromedino.com/" },
  { name: "Bloxorz", url: "https://bloxorz.io/" },
  {
    name: "a1rplayis",
    url: "https://a1rplayis.us/"
  },
  { name: "1v1.lol", url: "https://1v1.lol/" },
  {
    name: "Slope",
    url: "https://slopeio.org/"
  },
  { name: "Neal.fun", url: "https://neal.fun/" },
  { name: "Paper.io", url: "https://paper-io.com/" },
  {
    name: "Super Smash Flash",
    url: "https://www.supersmashflash.com/play/ssf2/"
  },
  { name: "World's Biggest Pac-Man", url: "http://www.pacman.com/" }
];

const searchButton = document.getElementById("search-button");
const searchInput = document.getElementById("search-input");
const gameList = document.getElementById("game-list");
const gameFrame = document.getElementById("game-frame");
const fullscreenButton = document.getElementById("fullscreen-button");

searchButton.addEventListener("click", () => {
  const searchTerm = searchInput.value.toLowerCase();
  gameList.innerHTML = "";

  const filteredGames = games.filter((game) =>
    game.name.toLowerCase().includes(searchTerm)
  );

  filteredGames.forEach((game) => {
    const link = document.createElement("a");
    link.href = "#";
    link.classList.add("game-link");
    link.textContent = game.name;
    link.addEventListener("click", () => {
      gameFrame.src = game.url;
    });
    gameList.appendChild(link);
  });

  if (filteredGames.length === 0) {
    gameList.innerHTML = "No games found.";
  }
});

fullscreenButton.addEventListener("click", () => {
  if (gameFrame.requestFullscreen) {
    gameFrame.requestFullscreen();
  } else if (gameFrame.mozRequestFullScreen) {
    // Firefox
    gameFrame.mozRequestFullScreen();
  } else if (gameFrame.webkitRequestFullscreen) {
    // Chrome, Safari and Opera
    gameFrame.webkitRequestFullscreen();
  } else if (gameFrame.msRequestFullscreen) {
    // IE/Edge
    gameFrame.msRequestFullscreen();
  }
});
